from typing import Tuple, List, Union, Optional
from typing_extensions import Literal
from typing import ClassVar
from config import Config

class Dataset(Config):
    name: str
    n_samples: Optional[int] = None
    select_views: Optional[Tuple[int, ...]] = None
    select_labels: Optional[Tuple[int, ...]] = None
    label_counts: Optional[Tuple[int, ...]] = None
    noise_sd: Optional[float] = None
    noise_views: Optional[Tuple[int, ...]] = None

class Loss(Config):
    n_clusters: Optional[int] = None
    funcs: str
    weights: Optional[Tuple[Union[float, int], ...]] = None
    rel_sigma: ClassVar[float] = 0.15
    tau: ClassVar[float] = 0.0001
    alpha: ClassVar[float] = 0.1
    negative_samples_ratio: float = 0.25
    contrastive_similarity: Literal["cos", "gauss"] = "cos"
    adaptive_contrastive_weight: bool = False
    c1: float = 0.1
    beta: float = 0.15

    lam: ClassVar[float] = 2.101

class Optimizer(Config):
    learning_rate: float = 0.001
    clip_norm: float = 5.0
    scheduler_step_size: Optional[int] = 40
    scheduler_gamma: float = 0.1


class DDC(Config):
    n_clusters: Optional[int] = None
    n_hidden: int = 100
    use_bn: bool = True

class CNN(Config):
    input_size: Optional[Tuple[int, ...]] = (3, 64, 64)  # 假设输入是 3 通道，64x64 的图像
    layers: Tuple[Tuple[str, int, int, int, Optional[str]], ...] = (
        ("conv", 3, 3, 32, "relu"),  # 卷积核 3x3，32 个过滤器
        ("bn",),                     # 批归一化
        ("relu",),                   # ReLU 激活
        ("pool", 2, 2),              # 2x2 最大池化
        ("conv", 3, 3, 64, "relu"),  # 卷积核 3x3，64 个过滤器
        ("bn",),                     # 批归一化
        ("relu",),                   # ReLU 激活
        ("pool", 2, 2),              # 2x2 最大池化
        ("conv", 3, 3, 128, "relu"), # 卷积核 3x3，128 个过滤器
        ("bn",),                     # 批归一化
        ("relu",),                   # ReLU 激活
        ("pool", 2, 2),              # 2x2 最大池化
    )


# class CNN(Config):
#     input_size: Optional[Tuple[int, ...]] = 3
#     layers: Tuple[Tuple[str, int, int, int, Optional[str]], ...] = (
#         ("conv", 5, 5, 32, "relu"),
#         ("conv", 5, 5, 32, None),
#         ("bn",),
#         ("relu",),
#         ("pool", 2, 2),
#         ("conv", 3, 3, 32, "relu"),
#         ("conv", 3, 3, 32, None),
#         ("bn",),
#         ("relu",),
#         ("pool", 2, 2),
#     )

class ResNet(Config):
    block: Literal["BasicBlock", "weighted_mean"]

class VGG(Config):
    block: Literal["BasicBlock", "weighted_mean"]

class MLP(Config):
    input_size: Optional[Tuple[int, ...]] = None
    layers: Tuple[Union[int, str], ...] = (256, 512, 256)
    activation: Union[str, None, List[Union[None, str]], Tuple[Union[None, str], ...]] = "relu"
    use_bias: Union[bool, Tuple[bool, ...]] = True
    use_bn: Union[bool, Tuple[bool, ...]] = True

class Fusion(Config):
    method: Literal["mean", "weighted_mean"]
    n_views: int

class DDCModel(Config):
    backbone_config: Union[MLP, CNN]
    cm_config: DDC
    loss_config: Loss
    optimizer_config: Optimizer = Optimizer()

class PGCLDCL(Config):
    backbone_configs: Tuple[Union[VGG, MLP, CNN], ...]
    projector_config: Optional[MLP] = True
    fusion_config: Fusion
    cm_config: DDC
    loss_config: Loss
    optimizer_config: Optimizer = Optimizer()

class Experiment(Config):
    dataset_config: Dataset
    model_configs: Union[PGCLDCL, DDC]
    n_runs: int = 1
    n_epochs: int = 120
    batch_size: int = 100

    eval_interval: int = 4
    checkpoint_interval: int = 20
    patience: int = 20000
    n_eval_samples: Optional[int] = None
    best_loss_term: str = "Cluster"
    seed: int = 42
    # lam: float = 0.1

