from config.defaults import Experiment, DDC, Fusion, MLP, Loss, Dataset, PGCLDCL, Optimizer
MNIST_USPS = Experiment(
    dataset_config=Dataset(name="MNIST-USPS"),
    model_configs=PGCLDCL(
        backbone_configs=(
            MLP(input_size=(784,)),
            MLP(input_size=(256,)),
        ),
        fusion_config=Fusion(method="weighted_mean", n_views=2),
        projector_config=None,
        cm_config=DDC(n_clusters=7),
        loss_config=Loss(
            funcs="ddc_1|ddc_2|ddc_3|Alignment|Clu|mi_fused",
            delta=20.0
        ),
        optimizer_config=Optimizer(scheduler_step_size=50, scheduler_gamma=0.1)
    ),
)
