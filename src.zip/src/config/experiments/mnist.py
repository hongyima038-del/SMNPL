from config.defaults import Experiment, DDC, Fusion, MLP, Loss, Dataset, PGCLDCL, Optimizer

MNIST = Experiment(
    dataset_config=Dataset(name="mnist_mv"),
    model_configs=PGCLDCL(
        backbone_configs=(
            MLP(input_size=(784,)),  # MNIST 数据集的每个图像为28x28像素，因此输入大小为784
            MLP(input_size=(784,)),
        ),
        fusion_config=Fusion(method="weighted_mean", n_views=2),
        projector_config=None,
        cm_config=DDC(n_clusters=7),  # MNIST 有10个数字类别
        loss_config=Loss(
            funcs="ddc_1|ddc_2|ddc_3|Alignment|Clu|mi_fused",
            delta=10.0  # MNIST 的聚类可能更简单，减少了 delta
        ),
        optimizer_config=Optimizer(scheduler_step_size=50, scheduler_gamma=0.1)
    ),
)
