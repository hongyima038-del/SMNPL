from config.defaults import Experiment, DDC, Fusion, MLP, Loss, Dataset, PGCLDCL, Optimizer

swelling = Experiment(
    dataset_config=Dataset(name="swelling"),  # .npz文件名
    model_configs=PGCLDCL(
        backbone_configs=(
            MLP(input_size=(5,)),   # view_0: 肿胀相关指标维度（示例，替换为实际值）
            MLP(input_size=(8,)),   # view_1: 功能相关指标维度（示例，替换为实际值）
            MLP(input_size=(8,)),   # view_1: 功能相关指标维度（示例，替换为实际值）
        ),
        fusion_config=Fusion(
            method="weighted_mean",  # 融合方式：可选 concat / mean / weighted_mean 等
            n_views=2
        ),
        projector_config=None,
        cm_config=DDC(n_clusters=3),  # 类别数，根据你的伪标签设为2
        loss_config=Loss(
            funcs="ddc_1|ddc_2|ddc_3|Alignment|Clu|mi_fused",  # 多任务损失组合
            delta=20.0
        ),
        optimizer_config=Optimizer(
            scheduler_step_size=20,
            scheduler_gamma=0.1
        )
    ),
)
