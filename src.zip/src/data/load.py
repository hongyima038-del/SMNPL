import numpy as np
import torch as th

import config


# def _load_npz(name):
#     return np.load(config.DATA_DIR / "processed" / f"{name}.npz")
#
#
# def _fix_labels(l):
#     uniq = np.unique(l)[None, :]
#     new = (l[:, None] == uniq).argmax(axis=1)
#     return new
#
#
# import numpy as np
# import torch as th
# import config  # 确保你有这个配置模块
#
#
# def _load_npz(name):
#     return np.load(f'data/processed/{name}.npz')
#
#
# def _fix_labels(labels):
#     # 在此添加任何需要对标签进行处理的代码
#     return labels
#
#
# def load_dataset(name, n_samples=None, select_views=None, select_labels=None, label_counts=None, noise_sd=None,
#                  noise_views=None, to_dataset=True, **kwargs):
#     npz = _load_npz(name)
#     labels = npz["labels"].flatten()  # 将标签从 (8677, 1) 转换为 (8677,)
#     n_views = int(npz["n_views"])  # 确保 n_views 是整数
#     views = []
#
#     # 加载所有视图
#     for i in range(n_views):
#         view_key = f"view_{i}"
#         if view_key in npz:
#             views.append(npz[view_key])
#         else:
#             raise KeyError(f"Key {view_key} not found in npz file")
#
#     # 打印视图的形状
#     print("Shapes of views:")
#     for i, v in enumerate(views):
#         print(f"view_{i} shape: {v.shape}")
#
#     print("Labels shape:", labels.shape)
#
#     # 选择特定标签
#     if select_labels is not None:
#         mask = np.isin(labels, select_labels)
#         labels = labels[mask]
#         views = [v[mask] for v in views]
#
#         # 确保视图和标签的长度匹配
#         assert all(v.shape[0] == labels.shape[0] for v in views), "View and label size mismatch after filtering."
#
#     # 根据标签计数选择样本
#     if label_counts is not None:
#         idx = []
#         unique_labels = np.unique(labels)
#         assert len(unique_labels) == len(label_counts)
#         for l, n in zip(unique_labels, label_counts):
#             _idx = np.random.choice(np.where(labels == l)[0], size=n, replace=False)
#             idx.append(_idx)
#
#         idx = np.concatenate(idx, axis=0)
#         labels = labels[idx]
#         views = [v[idx] for v in views]
#
#         # 确保视图和标签的长度匹配
#         assert all(v.shape[0] == labels.shape[0] for v in views), "View and label size mismatch after counting."
#
#     # 随机选择样本
#     if n_samples is not None:
#         idx = np.random.choice(labels.shape[0], size=min(labels.shape[0], int(n_samples)), replace=False)
#         labels = labels[idx]
#         views = [v[idx] for v in views]
#
#         # 确保视图和标签的长度匹配
#         assert all(v.shape[0] == labels.shape[0] for v in views), "View and label size mismatch after sampling."
#
#     # 选择特定视图
#     if select_views is not None:
#         if not isinstance(select_views, (list, tuple)):
#             select_views = [select_views]
#         views = [views[i] for i in select_views]
#
#     # 添加噪声
#     if noise_sd is not None:
#         assert noise_views is not None, "'noise_views' has to be specified when 'noise_sd' is not None."
#         if not isinstance(noise_views, (list, tuple)):
#             noise_views = [int(noise_views)]
#         for v in noise_views:
#             views[v] += np.random.normal(loc=0, scale=float(noise_sd), size=views[v].shape)
#
#     # 转换数据类型
#     views = [v.astype(np.float32) for v in views]
#
#     # 创建 TensorDataset
#     if to_dataset:
#         dataset = th.utils.data.TensorDataset(*[th.Tensor(v).to(config.DEVICE, non_blocking=True) for v in views],
#                                               th.Tensor(labels).to(config.DEVICE, non_blocking=True))
#     else:
#         dataset = (views, labels)
#
#     return dataset










import numpy as np
import torch as th

def _load_npz(name, path="data/processed"):
    return np.load(f"{path}/{name}.npz")

def _fix_labels(labels):

    uniq = np.unique(labels)
    return np.array([np.where(uniq == l)[0][0] for l in labels])

def load_dataset(name, n_samples=None, select_views=None, select_labels=None, label_counts=None, noise_sd=None,
                      noise_views=None, to_dataset=True, device="cpu"):
    npz = _load_npz(name)
    labels = _fix_labels(npz["labels"].flatten())
    n_views = int(npz["n_views"])

    for i in range(int(npz['n_views'])):
        print(f"view_{i} shape:", npz[f"view_{i}"].shape)

    views = []
    for i in range(n_views):
        view_key = f"view_{i}"
        if view_key not in npz:
            raise KeyError(f"{view_key} not found in dataset.")
        views.append(npz[view_key])

    if select_labels is not None:
        mask = np.isin(labels, select_labels)
        labels = labels[mask]
        views = [v[mask] for v in views]

    if label_counts is not None:
        idx = []
        for l, n in zip(np.unique(labels), label_counts):
            idx.extend(np.random.choice(np.where(labels == l)[0], size=n, replace=False))
        labels = labels[idx]
        views = [v[idx] for v in views]

    if n_samples is not None:
        idx = np.random.choice(len(labels), size=n_samples, replace=False)
        labels = labels[idx]
        views = [v[idx] for v in views]

    if select_views is not None:
        views = [views[i] for i in select_views]

    if noise_sd is not None:
        for i in noise_views:
            views[i] += np.random.normal(0, noise_sd, views[i].shape)

    views = [v.astype(np.float32) for v in views]

    if to_dataset:
        tensors = [th.tensor(v).to(device) for v in views] + [th.tensor(labels).long().to(device)]
        return th.utils.data.TensorDataset(*tensors)
    else:
        return views, labels



















































# def load_dataset(name, n_samples=None, select_views=None, select_labels=None, label_counts=None, noise_sd=None,
#                  noise_views=None, to_dataset=True, **kwargs):
#     npz = _load_npz(name)
#     labels = npz["labels"]
#     # views = [npz[f"view_{i}"] for i in range(npz["n_views"])]
#     n_views = int(npz["n_views"])  # 确保 n_views 是整数
#     views = []
#
#     for i in range(n_views):
#         view_key = f"view_{i}"
#         if view_key in npz:
#             views.append(npz[view_key])
#         else:
#             raise KeyError(f"Key {view_key} not found in npz file")
#
#
#     if select_labels is not None:
#         mask = np.isin(labels, select_labels)
#         labels = labels[mask]
#         views = [v[mask] for v in views]
#         labels = _fix_labels(labels)
#
#     if label_counts is not None:
#         idx = []
#         unique_labels = np.unique(labels)
#         assert len(unique_labels) == len(label_counts)
#         for l, n in zip(unique_labels, label_counts):
#             _idx = np.random.choice(np.where(labels == l)[0], size=n, replace=False)
#             idx.append(_idx)
#
#         idx = np.concatenate(idx, axis=0)
#         labels = labels[idx]
#         views = [v[idx] for v in views]
#
#     if n_samples is not None:
#         idx = np.random.choice(labels.shape[0], size=min(labels.shape[0], int(n_samples)), replace=False)
#         labels = labels[idx]
#         views = [v[idx] for v in views]
#
#     if select_views is not None:
#         if not isinstance(select_views, (list, tuple)):
#             select_views = [select_views]
#         views = [views[i] for i in select_views]
#
#     if noise_sd is not None:
#         assert noise_views is not None, "'noise_views' has to be specified when 'noise_sd' is not None."
#         if not isinstance(noise_views, (list, tuple)):
#             noise_views = [int(noise_views)]
#         for v in noise_views:
#             views[v] += np.random.normal(loc=0, scale=float(noise_sd), size=views[v].shape)
#
#     views = [v.astype(np.float32) for v in views]
#     if to_dataset:
#         dataset = th.utils.data.TensorDataset(*[th.Tensor(v).to(config.DEVICE, non_blocking=True) for v in views],
#                                               th.Tensor(labels).to(config.DEVICE, non_blocking=True))
#     else:
#         dataset = (views, labels)
#     return dataset
