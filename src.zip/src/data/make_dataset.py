# import numpy as np
# import os
#
# def export_dataset(name, views, labels):
#     np.savez_compressed(f'data/processed/{name}.npz', **{
#         'n_views': len(views),
#         'labels': labels,
#         **{f'view_{i}': view for i, view in enumerate(views)}
#     })
#
# def make_dataset(dataset_names):
#     for dataset_name in dataset_names:
#         raw_path = os.path.join('data', 'raw', dataset_name)
#         if not os.path.exists(raw_path):
#             print(f"Dataset {dataset_name} not found in raw data folder.")
#             continue
#
#         # Assuming raw data files are numpy arrays for each view and labels.
#         # Modify this part based on the actual raw data format.
#         views = [np.load(os.path.join(raw_path, f'view_{i}.npy')) for i in range(3)]
#         labels = np.load(os.path.join(raw_path, 'labels.npy'))
#
#         export_dataset(dataset_name, views, labels)
#         print(f"Processed dataset {dataset_name} and saved to data/processed/{dataset_name}.npz")
#
# if __name__ == '__main__':
#     import sys
#     dataset_names = sys.argv[1:]
#     make_dataset(dataset_names)


# import numpy as np
# import os
# import scipy.io as sio  # 用于加载 .mat 文件
#
# def export_dataset(name, views, labels):
#     np.savez_compressed(f'data/processed/{name}.npz', **{
#         'n_views': len(views),
#         'labels': labels,
#         **{f'view_{i}': view for i, view in enumerate(views)}
#     })
#
# def make_dataset(dataset_names):
#     for dataset_name in dataset_names:
#         raw_path = os.path.join('data', 'raw', dataset_name)
#         if not os.path.exists(raw_path):
#             print(f"Dataset {dataset_name} not found in raw data folder.")
#             continue
#
#         # Assuming raw data files are numpy arrays for each view and labels.
#         # Modify this part based on the actual raw data format.
#         views = [sio.loadmat(os.path.join(raw_path, f'view{i}.mat')) for i in range(1, 4)]
#         labels = np.load(os.path.join(raw_path, 'labels'))
#
#         export_dataset(dataset_name, views, labels)
#         print(f"Processed dataset {dataset_name} and saved to data/processed/{dataset_name}.npz")
#
# if __name__ == '__main__':
#     import sys
#     dataset_names = sys.argv[1:]
#     make_dataset(dataset_names)
#
#







#
#
# import numpy as np
# import os
# import scipy.io as sio
#
#
# def export_dataset(name, views, labels):
#     np.savez_compressed(f'data/processed/{name}.npz', **{
#         # 'n_views': len(views),
#         'labels': labels,
#         'n_views': len(views),
#         **{f'view_{i}': view for i, view in enumerate(views)}
#     })
#
#
# def make_dataset(dataset_names):
#     for dataset_name in dataset_names:
#         raw_path = os.path.join('data', 'raw', dataset_name)
#         if not os.path.exists(raw_path):
#             print(f"Dataset {dataset_name} not found in raw data folder.")
#             continue
#
#         # 读取视图数据
#         views = []
#         labels = None  # 用于存储标签
#         for i in range(1, 4):  # 假设有 3 个视图文件：view1.mat, view2.mat, view3.mat
#             view_path = os.path.join(raw_path, f'view{i}.mat')
#             if os.path.exists(view_path):
#                 mat_data = sio.loadmat(view_path)
#                 # 假设视图数据在 'fea' 键中
#                 views.append(mat_data['fea'])
#                 # 从第一个视图文件中获取标签数据
#                 if labels is None and 'truelabel' in mat_data:
#                     labels = mat_data['truelabel'].flatten()  # 将标签数据转换为一维数组
#             else:
#                 print(f"View file {view_path} not found.")
#
#         if labels is None:
#             print(f"Labels not found in any view file for dataset {dataset_name}.")
#             continue
#
#         # 导出为 .npz 文件
#         export_dataset(dataset_name, views, labels)
#         print(f"Processed dataset {dataset_name} and saved to data/processed/{dataset_name}.npz")
#
#
# if __name__ == '__main__':
#     import sys
#
#     dataset_names = sys.argv[1:]
#     make_dataset(dataset_names)



#
# import numpy as np
# import os
# from scipy.io import loadmat
#
# def export_dataset(name, views, labels):
#     np.savez_compressed(f'data/processed/{name}.npz', **{
#         'n_views': len(views),
#         'labels': labels,
#         **{f'view_{i}': view for i, view in enumerate(views)}
#     })
#
# def make_dataset(dataset_names):
#     for dataset_name in dataset_names:
#         raw_path = os.path.join('data', 'raw', dataset_name)
#         if not os.path.exists(raw_path):
#             print(f"Dataset {dataset_name} not found in raw data folder.")
#             continue
#
#         # Load the MATLAB file
#         mat_file = os.path.join(raw_path, f'{dataset_name}.mat')
#         mat_data = loadmat(mat_file)
#
#         # Extract views and labels from the MATLAB data
#         # 逐一提取每一列的视图数据，并转置
#         views = []
#         for i in range(3):
#             view_data = mat_data['data'][0][0][i]
#             if isinstance(view_data, np.ndarray):
#                 views.append(view_data.T)
#             else:
#                 print(f"View {i} is not a numpy array and was skipped.")
#
#         # 将标签展平成一维整型数组
#         if 'truelabel' in mat_data:
#             labels = np.array(
#                 [item[0] if isinstance(item, (list, np.ndarray)) else item for item in mat_data['truelabel']])
#             labels = labels.astype(np.int64)
#             labels = labels[0][:50000]  # 只保留前50000个标签
#         else:
#             print("No labels found in 'truelabel' key.")
#
#         export_dataset(dataset_name, views, labels)
#         print(f"Processed dataset {dataset_name} and saved to data/processed/{dataset_name}.npz")
#
# if __name__ == '__main__':
#     import sys
#     dataset_names = sys.argv[1:]
#     make_dataset(dataset_names)
#















import numpy as np
import os
from scipy.io import loadmat

def export_dataset(name, views, labels):
    np.savez_compressed(f'data/processed/{name}.npz', **{
        'n_views': len(views),
        'labels': labels,
        **{f'view_{i}': view for i, view in enumerate(views)}
    })

def make_dataset(dataset_names):
    for dataset_name in dataset_names:
        raw_path = os.path.join('data', 'raw', dataset_name)
        if not os.path.exists(raw_path):
            print(f"Dataset {dataset_name} not found in raw data folder.")
            continue

        # Load the MATLAB file
        mat_file = os.path.join(raw_path, f'{dataset_name}.mat')
        mat_data = loadmat(mat_file)

        # Extract views and labels from the MATLAB data
        views = [mat_data['x_train'][i] for i in range(5)]  # 提取五个视图
        labels = mat_data['y_train']
        labels = labels.flatten()

        export_dataset(dataset_name, views, labels)
        print(f"Processed dataset {dataset_name} and saved to data/processed/{dataset_name}.npz")

if __name__ == '__main__':
    import sys
    dataset_names = sys.argv[1:]
    make_dataset(dataset_names)
