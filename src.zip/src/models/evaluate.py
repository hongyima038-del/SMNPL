import os
import argparse
import numpy as np
import torch as th
import matplotlib.pyplot as plt
import seaborn as sns
from tabulate import tabulate
from sklearn.metrics import normalized_mutual_info_score
import statistics
import pandas as pd
from sklearn.metrics import normalized_mutual_info_score, adjusted_rand_score  # 引入 adjusted_rand_score
import config
import helpers
from models.build_model import from_file
# 计算总体损失时忽略contrast部分
IGNORE_IN_TOTAL = ("mi_fused",)


class Config:
    # 设置受保护的命名空间为空，以防止与内部保留关键字冲突
    protected_namespaces = ()

def calc_metrics(labels, pred):
    """
    Compute metrics.

    :param labels: Label tensor
    :type labels: th.Tensor
    :param pred: Predictions tensor
    :type pred: th.Tensor
    :return: Dictionary containing calculated metrics
    :rtype: dict
    """
    acc, cmat = helpers.ordered_cmat(labels, pred)
    metrics = {
        "acc": acc,
        "cmat": cmat,
        "nmi": normalized_mutual_info_score(labels, pred, average_method="geometric"),
        "ari": adjusted_rand_score(labels, pred),  # 计算 ARI
    }
    return metrics


def calc_acc(labels, pred):
    """
    Compute metrics.

    :param labels: Label tensor
    :type labels: th.Tensor
    :param pred: Predictions tensor
    :type pred: th.Tensor
    :return: Dictionary containing calculated metrics
    :rtype: dict
    """
    acc, cmat = helpers.ordered_cmat(labels, pred)
    metrics = {
        "acc": acc,
    }
    return metrics


def calc_nmi(labels, pred):
    """
    Compute metrics.

    :param labels: Label tensor
    :type labels: th.Tensor
    :param pred: Predictions tensor
    :type pred: th.Tensor
    :return: Dictionary containing calculated metrics
    :rtype: dict
    """
    acc, cmat = helpers.ordered_cmat(labels, pred)
    metrics = {
        "nmi": normalized_mutual_info_score(labels, pred, average_method="geometric"),
    }
    return metrics

def calc_ari(labels, pred):
    metrics = {"ari": adjusted_rand_score(labels, pred)}  # 单独计算 ARI
    return metrics
def get_log_params(net):
    """
    Get the network parameters we want to log.

    :param net: Model
    :type net:
    :return:
    :rtype:
    """
    params_dict = {}
    weights = []
    if getattr(net, "fusion", None) is not None:
        with th.no_grad():
            weights = net.fusion.get_weights(softmax=True)

    elif hasattr(net, "attention"):
        weights = net.weights

    for i, w in enumerate(helpers.npy(weights)):
        params_dict[f"fusion/weight_{i}"] = w

    if hasattr(net, "discriminators"):
        for i, discriminator in enumerate(net.discriminators):
            d0, dv = helpers.npy([discriminator.d0, discriminator.dv])
            params_dict[f"discriminator_{i}/d0/mean"] = d0.mean()
            params_dict[f"discriminator_{i}/d0/std"] = d0.std()
            params_dict[f"discriminator_{i}/dv/mean"] = dv.mean()
            params_dict[f"discriminator_{i}/dv/std"] = dv.std()

    return params_dict


def get_eval_data(dataset, n_eval_samples, batch_size):
    """
    Create a dataloader to use for evaluation

    :param dataset: Inout dataset.
    :type dataset: th.utils.data.Dataset
    :param n_eval_samples: Number of samples to include in the evaluation dataset. Set to None to use all available
                           samples.
    :type n_eval_samples: int
    :param batch_size: Batch size used for training.
    :type batch_size: int
    :return: Evaluation dataset loader
    :rtype: th.utils.data.DataLoader
    """
    if n_eval_samples is not None:
        *views, labels = dataset.tensors
        n = views[0].size(0)
        idx = np.random.choice(n, min(n, n_eval_samples), replace=False)
        views, labels = [v[idx] for v in views], labels[idx]
        dataset = th.utils.data.TensorDataset(*views, labels)

    eval_loader = th.utils.data.DataLoader(dataset, batch_size=int(batch_size), shuffle=True, num_workers=0,
                                           drop_last=False, pin_memory=False)
    return eval_loader


def batch_predict(net, eval_data, batch_size):
    """
    Compute predictions for `eval_data` in batches. Batching does not influence predictions, but it influences the loss
    computations.

    :param net: Model
    :type net:
    :param eval_data: Evaluation dataloader
    :type eval_data: th.utils.data.DataLoader
    :param batch_size: Batch size
    :type batch_size: int
    :return: Label tensor, predictions tensor, list of dicts with loss values, array containing mean and std of cluster
             sizes.
    :rtype:
    """
    predictions = []
    labels = []
    losses = []
    cluster_sizes = []

    net.eval()
    with th.no_grad():
        for i, (*batch, label) in enumerate(eval_data):
            pred, _, _= net(batch)
            labels.append(helpers.npy(label))
            predictions.append(helpers.npy(pred).argmax(axis=1))

            # 若数据不足一个batch_size,则不计算， 在计算tot_loss时忽略ignore_in_total部分
            if label.size(0) == batch_size:
                batch_losses = net.calc_losses(ignore_in_total=IGNORE_IN_TOTAL)
                losses.append(helpers.npy(batch_losses))
                cluster_sizes.append(helpers.npy(pred.sum(dim=0)))

    labels = np.concatenate(labels, axis=0)
    predictions = np.concatenate(predictions, axis=0)
    net.train()
    return labels, predictions, losses, np.array(cluster_sizes).mean(axis=0)


def get_logs(cfg, net, eval_data, iter_losses=None, epoch=None, include_params=True, is_boost=False):
    tot_loss = 0

    if is_boost:
        logs = {}
    elif iter_losses is not None:
        logs = helpers.add_prefix(helpers.dict_means(iter_losses), "iter_losses")
    else:
        logs = {}
    # 每四轮评估一遍，输出全部指标
    if (epoch is None) or ((epoch % cfg.eval_interval) == 0):
        # 从eval_data中取出标签，用net计算聚类预测标签，得到评估数据的各项损失函数的值，其中eval_losses包含14个batch的损失值
        labels, pred, eval_losses, cluster_sizes = batch_predict(net, eval_data, cfg.batch_size)
        # 计算所有batch样本的平均值
        eval_losses = helpers.dict_means(eval_losses)
        # 把去除contrast部分的总损失值保存，并最后返回给train.py
        # tot_loss = eval_losses['tot']
        # add_prefix用来增加各项指标的前缀说明，用于console中输出
        logs.update(helpers.add_prefix(eval_losses, "eval_losses"))
        # 计算acc、cmat、nmi
        logs.update(helpers.add_prefix(calc_metrics(labels, pred), "metrics"))

        # print(eval_losses['tot'])
        logs.update(helpers.add_prefix({"mean": cluster_sizes.mean(), "sd": cluster_sizes.std()}, "cluster_size"))

    if include_params:
        logs.update(helpers.add_prefix(get_log_params(net), "params"))
    if epoch is not None:
        logs["epoch"] = epoch

    return logs


def acc_logs(cfg, net, eval_data):
    labels, pred, eval_losses, cluster_sizes = batch_predict(net, eval_data, cfg.batch_size)
    logs = helpers.add_prefix(calc_acc(labels, pred), "metrics")
    return logs


def nmi_logs(cfg, net, eval_data):
    labels, pred, eval_losses, cluster_sizes = batch_predict(net, eval_data, cfg.batch_size)
    logs = helpers.add_prefix(calc_nmi(labels, pred), "metrics")
    return logs

def ari_logs(cfg, net, eval_data):
    labels, pred, eval_losses, cluster_sizes = batch_predict(net, eval_data, cfg.batch_size)
    logs = helpers.add_prefix(calc_ari(labels, pred), "metrics")
    return logs


def eval_run(cfg, cfg_name, experiment_identifier, run, net, eval_data, callbacks=tuple(), load_best=True):
    """
    Evaluate a training run.

    :param cfg: Experiment config
    :type cfg: config.defaults.Experiment
    :param cfg_name: Config name
    :type cfg_name: str
    :param experiment_identifier: 8-character unique identifier for the current experiment
    :type experiment_identifier: str
    :param run: Run to evaluate
    :type run: int
    :param net: Model
    :type net:
    :param eval_data: Evaluation dataloder
    :type eval_data: th.utils.data.DataLoader
    :param callbacks: List of callbacks to call after evaluation
    :type callbacks: List
    :param load_best: Load the "best.pt" model before evaluation?
    :type load_best: bool
    :return: Evaluation logs
    :rtype: dict
    """
    if load_best:
        model_path = helpers.get_save_dir(cfg_name, experiment_identifier, run) / "best.pt"
        if os.path.isfile(model_path):
            net.load_state_dict(th.load(model_path))
        else:
            print(f"Unable to load best model for evaluation. Model file not found: {model_path}")
    logs = get_logs(cfg, net, eval_data, include_params=True)
    for cb in callbacks:
        cb.at_eval(net=net, logs=logs)
    return logs

# 根据已训练好的模型（通过tag编号获得）来计算数据通过该模型之后的acc，nmi
from sklearn.metrics import adjusted_rand_score  # 引入 adjusted_rand_score




def eval_experiment(cfg_name, tag, plot=True):
    """
    Evaluate a full experiment

    :param cfg_name: Name of the config
    :type cfg_name: str
    :param tag: 8-character unique identifier for the current experiment
    :type tag: str
    :param plot: Display a scatterplot of the representations before and after fusion?
    :type plot: bool
    """
    max_n_runs = 100
    best_logs = None
    best_run = None
    best_net = None
    best_loss = np.inf
    acc_mean = []
    acc_std = []
    nmi_mean = []
    nmi_std = []
    ari_mean = []  # New ARI mean record
    ari_std = []   # New ARI std record

    # DataFrame to store results for each run
    run_results = pd.DataFrame(columns=["Run", "ACC", "NMI", "ARI"])

    for run in range(max_n_runs):
        try:
            net, views, labels, cfg = from_file(cfg_name, tag, run, ckpt="best", return_data=True, return_config=True)
        except FileNotFoundError:
            break
        index = np.arange(0, 1400)
        eval_dataset = th.utils.data.TensorDataset(*[th.tensor(v).to(config.DEVICE, non_blocking=True) for v in views],
                                                   th.tensor(labels).to(config.DEVICE, non_blocking=True),
                                                  )
        eval_data = get_eval_data(eval_dataset, cfg.n_eval_samples, cfg.batch_size)
        run_logs = eval_run(cfg, cfg_name, tag, run, net, eval_data, load_best=True)
        del run_logs["metrics/cmat"]

        # Append metrics to lists
        acc_mean.append(run_logs["metrics/acc"])
        acc_std.append(run_logs["metrics/acc"])
        nmi_mean.append(run_logs["metrics/nmi"])
        nmi_std.append(run_logs["metrics/nmi"])
        ari_mean.append(run_logs["metrics/ari"])
        ari_std.append(run_logs["metrics/ari"])

        # Save results of each run in the DataFrame
        run_results = run_results.append({"Run": run,
                                          "ACC": run_logs["metrics/acc"],
                                          "NMI": run_logs["metrics/nmi"],
                                          "ARI": run_logs["metrics/ari"]},
                                         ignore_index=True)

        if run_logs[f"eval_losses/{cfg.best_loss_term}"] < best_loss:
            best_loss = run_logs[f"eval_losses/{cfg.best_loss_term}"]
            best_logs = run_logs
            best_run = run
            best_net = net

    print(f"\nBest run was {best_run}.", end="\n\n")
    headers = ["Name", "Value"]
    values = list(best_logs.items())
    acc = values[7][1]
    nmi = values[8][1]
    print(tabulate(values, headers=headers), "\n")

    # Output means and std for ACC, NMI, ARI
    print("ACC mean and std")
    print(statistics.mean(acc_mean))
    print(statistics.pstdev(acc_std))
    print("NMI mean and std")
    print(statistics.mean(nmi_mean))
    print(statistics.pstdev(nmi_std))
    print("ARI mean and std")
    print(statistics.mean(ari_mean))
    print(statistics.pstdev(ari_std))

    # Display the DataFrame of run results
    print("\nRun Results:")
    print(run_results)

    if plot:
        plot_representations(views, labels, best_net)
        plt.show()

    return acc, nmi, statistics.mean(ari_mean)  # Return the mean of ARI












# def eval_experiment(cfg_name, tag, plot=True):
#     """
#     Evaluate a full experiment
#
#     :param cfg_name: Name of the config
#     :type cfg_name: str
#     :param tag: 8-character unique identifier for the current experiment
#     :type tag: str
#     :param plot: Display a scatterplot of the representations before and after fusion?
#     :type plot: bool
#     """
#     max_n_runs = 100
#     best_logs = None
#     best_run = None
#     best_net = None
#     best_loss = np.inf
#     acc_mean = []
#     acc_std = []
#     nmi_mean = []
#     nmi_std = []
#     ari_mean = []  # 新增 ARI 平均值的记录
#     ari_std = []   # 新增 ARI 标准差的记录
#
#     for run in range(max_n_runs):
#         try:
#             net, views, labels, cfg = from_file(cfg_name, tag, run, ckpt="best", return_data=True, return_config=True)
#         except FileNotFoundError:
#             break
#         index = np.arange(0, 1400)
#         eval_dataset = th.utils.data.TensorDataset(*[th.tensor(v).to(config.DEVICE, non_blocking=True) for v in views],
#                                                    th.tensor(labels).to(config.DEVICE, non_blocking=True),
#                                                   )
#         eval_data = get_eval_data(eval_dataset, cfg.n_eval_samples, cfg.batch_size)
#         run_logs = eval_run(cfg, cfg_name, tag, run, net, eval_data, load_best=True)
#         del run_logs["metrics/cmat"]
#
#
#
#         acc_mean.append(run_logs["metrics/acc"])
#         acc_std.append(run_logs["metrics/acc"])
#         nmi_mean.append(run_logs["metrics/nmi"])
#         nmi_std.append(run_logs["metrics/nmi"])
#         ari_mean.append(run_logs["metrics/ari"])
#         ari_std.append(run_logs["metrics/ari"])
#         print(f'run_logs{run_logs}')
#
#         if run_logs[f"eval_losses/{cfg.best_loss_term}"] < best_loss:
#             best_loss = run_logs[f"eval_losses/{cfg.best_loss_term}"]
#             best_logs = run_logs
#             best_run = run
#             best_net = net
#
#     print(f"\nBest run was {best_run}.", end="\n\n")
#     headers = ["Name", "Value"]
#
#     values = list(best_logs.items())
#     acc = values[7][1]
#     nmi = values[8][1]
#     print(tabulate(values, headers=headers), "\n")
#
#     # 输出平均值和标准差
#     print("acc均值和标准差")
#     print(statistics.mean(acc_mean))
#     print(statistics.pstdev(acc_std))
#     print("nmi均值和标准差")
#     print(statistics.mean(nmi_mean))
#     print(statistics.pstdev(nmi_std))
#     print("ari均值和标准差")  # 输出 ARI 的均值和标准差
#     print(statistics.mean(ari_mean))
#     print(statistics.pstdev(ari_std))
#
#     if plot:
#         plot_representations(views, labels, best_net)
#         plt.show()
#     return acc, nmi, statistics.mean(ari_mean)  # 返回 ARI 的均值


# def eval_experiment(cfg_name, tag, plot=False):
#     max_n_runs = 100
#     acc_vals = []  # 存储每个checkpoint的ACC
#     nmi_vals = []  # 存储每个checkpoint的NMI
#     ari_vals = []  # 存储每个checkpoint的ARI
#     epochs = []    # 存储epoch编号
#
#     for run in range(max_n_runs):
#         try:
#             net, views, labels, cfg = from_file(cfg_name, tag, run, ckpt="best", return_data=True, return_config=True)
#         except FileNotFoundError:
#             break
#
#         eval_dataset = th.utils.data.TensorDataset(
#             *[th.tensor(v).to(config.DEVICE, non_blocking=True) for v in views],
#             th.tensor(labels).to(config.DEVICE, non_blocking=True),
#         )
#         eval_data = get_eval_data(eval_dataset, cfg.n_eval_samples, cfg.batch_size)
#
#         # 获取每个epoch的评估日志
#         for epoch in range(cfg.eval_interval, cfg.n_epochs + 1, cfg.eval_interval):  # 从第0轮开始
#             logs = get_logs(cfg, net, eval_data, epoch=epoch - cfg.eval_interval, include_params=False)
#             acc_vals.append(logs["metrics/acc"])
#             nmi_vals.append(logs["metrics/nmi"])
#             ari_vals.append(logs["metrics/ari"])
#             epochs.append(epoch - cfg.eval_interval)  # 设置为从0开始
#
#     # 绘制ACC, NMI, ARI曲线
#     if plot:
#         plt.figure(figsize=(12, 6))
#         plt.plot(epochs, acc_vals, label="ACC", marker='o')
#         plt.plot(epochs, nmi_vals, label="NMI", marker='x')
#         plt.plot(epochs, ari_vals, label="ARI", marker='s')
#         plt.xlabel("Epochs")
#         plt.ylabel("Metric Value")
#         plt.title("ACC, NMI, and ARI over Epochs")
#         plt.legend()
#         plt.grid(True)
#         plt.show()
#
#
#     # 返回最后一个值作为结果
#     return acc_vals[-1], nmi_vals[-1], ari_vals[-1]






def plot_representations(views, labels, net, project_method="tsne"):
    with th.no_grad():
        # 将每个视图转换为张量
        a = [th.tensor(v) for v in views]

        # 获取模型的输出
        output = net([th.tensor(v) for v in views])

        # 如果 output 是元组，则取出第一个元素（假设第一个元素是模型的主要输出）
        if isinstance(output, tuple):
            output = output[0]  # 如果是元组，取第一个元素
        elif isinstance(output, list):
            output = output[0]  # 如果是列表，取第一个元素
        elif isinstance(output, th.Tensor):  # 如果是张量，直接使用
            pass
        else:
            raise TypeError("Expected output to be a list, tuple, or tensor, got: {}".format(type(output)))

        # 确保 output 转换为 NumPy 数组后进行操作
        pred = helpers.npy(output).argmax(axis=1)

        # 获取模型的其他输出
        hidden = helpers.npy(net.backbone_outputs)
        fused = helpers.npy(net.fused)

    # 对 a[2] 进行填充操作
    print(f"a[2]{len(a)}")
    a[0] = th.nn.functional.pad(a[0], (0, 214, 0, 0))


    begin = np.concatenate(a, axis=0)
    fused_hue = [str(l + 1) for l in pred]
    b = []
    b.append([str(l + 1) for l in labels])
    b.append([str(l + 1) for l in labels])

    begin_hue = np.concatenate(b, axis=0)

    view_cmap = "tab10"
    class_cmap = "hls"  # Set2
    fig, ax = plt.subplots(1, 2, figsize=(20, 10))

    plot_projection(X=begin, method=project_method, hue=begin_hue, ax=ax[0], title="epoch=0",
                    legend_title="cluster", hue_order=sorted(list(set(begin_hue))), cmap=view_cmap)
    plot_projection(X=fused, method=project_method, hue=fused_hue, ax=ax[1], title="ours epoch=20",
                    legend_title="Prediction", hue_order=sorted(list(set(begin_hue))), cmap=class_cmap)


def plot_projection(X, method, hue, ax, title=None, cmap="tab10", legend_title=None, legend_loc=1, **kwargs):
    X = project(X, method)
    pl = sns.scatterplot(x=X[:, 0], y=X[:, 1], hue=hue, ax=ax, legend="full", palette=cmap, **kwargs)
    leg = pl.get_legend()
    leg._loc = legend_loc
    if title is not None:
        ax.set_title(title)
    if legend_title is not None:
        leg.set_title(legend_title)


def project(X, method):
    if method == "pca":
        from sklearn.decomposition import PCA
        return PCA(n_components=2).fit_transform(X)
    elif method == "tsne":
        from sklearn.manifold import TSNE
        return TSNE(n_components=2).fit_transform(X)
    elif method is None:
        return X
    else:
        raise RuntimeError()


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--config", dest="cfg_name", required=True)
    parser.add_argument("-t", "--tag", dest="tag", required=True)
    parser.add_argument("--plot", action="store_true")
    return parser.parse_args()


def evaluate_test(cfg_name, tag, plot):
    acc, nmi = eval_experiment(cfg_name, tag, plot)
    return acc, nmi


if __name__ == '__main__':
    args = parse_args()
    eval_experiment(args.cfg_name, args.tag, args.plot)
