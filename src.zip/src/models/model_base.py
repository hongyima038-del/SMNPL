import torch.nn as nn


class ModelBase(nn.Module):
    def __init__(self):
        super().__init__()
        self.fusion = None
        self.optimizer = None
        self.loss = None

    def calc_losses(self, ignore_in_total=tuple()):
        return self.loss(self, ignore_in_total=ignore_in_total)

    # def train_step(self, batch, epoch, it, n_batches):
    #     self.optimizer.zero_grad()
    #     _ = self(batch)
    #     losses = self.calc_losses()
    #     losses["tot"].backward()
    #     self.optimizer.step(epoch + it / n_batches)
    #     return losses

    def train_step(self, batch, epoch, it, n_batches):
        self.optimizer.zero_grad()  # 清除梯度

        # 前向传播，获取所有损失
        _ = self(batch)
        losses = self.calc_losses()


        # 对齐损失的自步学习更新与反向传播
        alignment_loss = losses["Alignment"]
        v_i = self.loss.calc_self_paced_loss(alignment_loss, self.loss.cfg.lam)
        regularization = self.loss.soft_regularization(v_i, self.loss.cfg.lam)
        updated_alignment_loss = (v_i * alignment_loss) - regularization

        updated_alignment_loss.backward(retain_graph=True)  # 保留计算图，以便接下来的反向传播

        # 其他损失的反向传播和优化
        remaining_loss = sum(v for k, v in losses.items() if k != "Alignment")
        remaining_loss.backward()
        self.optimizer.step(epoch + it / n_batches)

        return losses
